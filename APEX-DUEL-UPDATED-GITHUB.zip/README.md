# Apex Duel — Ultimate Edition (Android)

Native Android edition of **Apex Duel — Ultimate Edition**, built with **Kotlin**, **Jetpack Compose**, Material 3, and a 100% offline hardware-accelerated 3D PBR circuit racing engine.

## Features
- **14 Tunable Cars**: Detailed 3D Toyota GR Supra GT300/GT500 and Bugatti EB110 SS variants with full Garage customizer (paint, finish, rims, calipers, window tint, stance, headlights, license plate, decals, engine stages 1–4, spoilers, body kits, exhausts, and underglow).
- **5 Circuits & Dynamic Atmosphere**: Alpine Mountain Circuit, Night City Circuit, Coastal Highway Circuit, Desert Racing Circuit, and Grand Prix International with Day/Sunset/Night lighting and Clear/Cloudy/Light Rain/Heavy Rain physics.
- **7 Game Modes**: Quick Race, Time Trial, 5-Round Championship, Drift Challenge, Elimination, Free Drive, and 1v1 AI Duel.
- **Native Android Integration**:
  - Immersive full-screen landscape racing viewport with notch/cutout support and screen wake-lock.
  - Native Android touch steering & sculpted billet racing pedals with tactile haptic feedback.
  - Hardware/gesture Back navigation (pauses active race, returns to garage, or prompts exit from title screen).
  - Auto-pause when app moves to the background.
  - Native Android Share sheet for Garage Photo captures (PNG) and Garage Save Backups (JSON), plus native Document Picker for Save Import.
  - 100% offline bundled assets and Google Fonts (`Chakra Petch`, `Plus Jakarta Sans`, `JetBrains Mono`) with a custom adaptive launcher icon.
