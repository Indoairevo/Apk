# Add project specific ProGuard rules here.
-keepclassmembers class com.example.game.ApexNativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
