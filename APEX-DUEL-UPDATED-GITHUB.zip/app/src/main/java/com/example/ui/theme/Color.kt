package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonDeep = Color(0xFF0B0F17)
val CarbonPanel = Color(0xFF131925)
val CarbonElevated = Color(0xFF1C2434)
val ApexOrange = Color(0xFFFF6D1F)
val ApexOrangeBright = Color(0xFFFF8A47)
val NitroCyan = Color(0xFF38D2FF)
val TextPrimary = Color(0xFFF4F7FB)
val TextMuted = Color(0xFF9AA7B8)
val BorderSubtle = Color(0x24FFFFFF)
val TelemetryRed = Color(0xFFEF4444)
