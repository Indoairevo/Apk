package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ApexDarkColorScheme = darkColorScheme(
    primary = ApexOrange,
    onPrimary = CarbonDeep,
    secondary = NitroCyan,
    onSecondary = CarbonDeep,
    tertiary = ApexOrangeBright,
    background = CarbonDeep,
    onBackground = TextPrimary,
    surface = CarbonPanel,
    onSurface = TextPrimary,
    surfaceVariant = CarbonElevated,
    onSurfaceVariant = TextMuted,
    outline = BorderSubtle,
    error = TelemetryRed,
    onError = TextPrimary
)

@Composable
fun ApexDuelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ApexDarkColorScheme,
        typography = ApexTypography,
        content = content
    )
}
