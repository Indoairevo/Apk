package com.example.game

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import com.example.R
import java.io.File

/**
 * Native Android bridge exposed to the 3D racing engine as `window.ApexAndroid`.
 * Handles crisp tactile haptics, garage photo export, JSON save export, and ready signaling.
 */
class ApexNativeBridge(
    private val context: Context,
    private val onGameReady: () -> Unit,
    private val onStatusMessage: (String) -> Unit
) {

    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        const val BRIDGE_NAME = "ApexAndroid"
        private const val MAX_BASE64_CHARS = 16 * 1024 * 1024 // 16 MB safety guard
        private const val MAX_JSON_CHARS = 2 * 1024 * 1024 // 2 MB safety guard
        private val SAFE_NAME_REGEX = Regex("[^a-zA-Z0-9._-]")
    }

    @JavascriptInterface
    fun notifyGameReady() {
        mainHandler.post { onGameReady() }
    }

    @JavascriptInterface
    fun hapticLight() {
        performVibrate(durationMs = 12L, amplitude = 65)
    }

    @JavascriptInterface
    fun hapticHeavy() {
        performVibrate(durationMs = 24L, amplitude = 155)
    }

    @JavascriptInterface
    fun saveBase64Image(filename: String, dataUrl: String) {
        if (dataUrl.length > MAX_BASE64_CHARS) {
            postMessage(context.getString(R.string.toast_export_failed))
            return
        }
        try {
            val base64Part = dataUrl.substringAfter("base64,", missingDelimiterValue = "")
            if (base64Part.isBlank()) {
                postMessage(context.getString(R.string.toast_export_failed))
                return
            }
            val bytes = Base64.decode(base64Part, Base64.DEFAULT)
            val safeName = sanitizeFilename(filename, defaultName = "apex-duel-photo.png", ext = ".png")
            val outFile = writeExportFile(safeName, bytes)
            shareFile(outFile, mimeType = "image/png", chooserTitle = context.getString(R.string.share_photo_chooser))
            postMessage(context.getString(R.string.toast_photo_saved))
        } catch (_: Exception) {
            postMessage(context.getString(R.string.toast_export_failed))
        }
    }

    @JavascriptInterface
    fun saveJsonBackup(filename: String, jsonContent: String) {
        if (jsonContent.isBlank() || jsonContent.length > MAX_JSON_CHARS) {
            postMessage(context.getString(R.string.toast_export_failed))
            return
        }
        try {
            val safeName = sanitizeFilename(filename, defaultName = "apex-duel-garage-save.json", ext = ".json")
            val outFile = writeExportFile(safeName, jsonContent.toByteArray(Charsets.UTF_8))
            shareFile(outFile, mimeType = "application/json", chooserTitle = context.getString(R.string.share_save_chooser))
            postMessage(context.getString(R.string.toast_save_exported))
        } catch (_: Exception) {
            postMessage(context.getString(R.string.toast_export_failed))
        }
    }

    private fun performVibrate(durationMs: Long, amplitude: Int) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (!vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {
            // Gracefully ignore devices without vibrator hardware
        }
    }

    private fun sanitizeFilename(raw: String, defaultName: String, ext: String): String {
        val cleaned = raw.trim().replace(SAFE_NAME_REGEX, "_").trim('.')
        val base = if (cleaned.isBlank()) defaultName else cleaned
        return if (base.endsWith(ext, ignoreCase = true)) base else "$base$ext"
    }

    private fun writeExportFile(filename: String, bytes: ByteArray): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, filename)
        file.writeBytes(bytes)
        return file
    }

    private fun shareFile(file: File, mimeType: String, chooserTitle: String) {
        mainHandler.post {
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = mimeType
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(shareIntent, chooserTitle).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (_: Exception) {
                onStatusMessage(context.getString(R.string.toast_export_failed))
            }
        }
    }

    private fun postMessage(message: String) {
        mainHandler.post { onStatusMessage(message) }
    }
}
