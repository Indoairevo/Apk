package com.example.game

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ApexUiState(
    val engineReady: Boolean = false,
    val loadError: String? = null,
    val showExitDialog: Boolean = false,
    val snackbarMessage: String? = null
)

class ApexGameViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ApexUiState())
    val uiState: StateFlow<ApexUiState> = _uiState.asStateFlow()

    fun onEngineReady() {
        _uiState.update { it.copy(engineReady = true, loadError = null) }
    }

    fun onLoadError(message: String) {
        _uiState.update { it.copy(loadError = message, engineReady = true) }
    }

    fun onRetryReload() {
        _uiState.update { it.copy(engineReady = false, loadError = null) }
    }

    fun showExitPrompt() {
        _uiState.update { it.copy(showExitDialog = true) }
    }

    fun dismissExitPrompt() {
        _uiState.update { it.copy(showExitDialog = false) }
    }

    fun postSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
