package com.example.game

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.IOException

/**
 * Serves the bundled Three.js 3D game from app/src/main/assets/game/ over a secure
 * virtual HTTPS origin so ES modules, WebGL textures, local fonts, and localStorage
 * work 100% offline with zero CORS restrictions.
 */
class LocalGameAssetHandler(private val context: Context) {

    companion object {
        const val VIRTUAL_HOST = "appassets.androidplatform.net"
        const val GAME_BASE_URL = "https://$VIRTUAL_HOST/game/index.html"
        private const val GAME_PATH_PREFIX = "/game/"
    }

    fun shouldIntercept(uri: Uri?): Boolean {
        return uri != null &&
            uri.scheme == "https" &&
            uri.host == VIRTUAL_HOST &&
            (uri.path?.startsWith(GAME_PATH_PREFIX) == true)
    }

    fun handleRequest(uri: Uri): WebResourceResponse {
        val rawRelative = uri.path.orEmpty().removePrefix(GAME_PATH_PREFIX)
        val normalized = normalizeSafePath(rawRelative)
            ?: return emptyNotFoundResponse()

        val assetPath = "game/$normalized"
        return try {
            val stream = context.assets.open(assetPath)
            val mimeType = guessMimeType(normalized)
            val encoding = if (isTextMime(mimeType)) "UTF-8" else null
            WebResourceResponse(
                mimeType,
                encoding,
                200,
                "OK",
                mapOf(
                    "Access-Control-Allow-Origin" to "https://$VIRTUAL_HOST",
                    "Cache-Control" to "no-cache"
                ),
                stream
            )
        } catch (_: IOException) {
            emptyNotFoundResponse()
        }
    }

    private fun normalizeSafePath(path: String): String? {
        if (path.isBlank()) return "index.html"
        val clean = path.trimStart('/')
        if (clean.contains("..") || clean.contains("\\") || clean.startsWith("/")) {
            return null
        }
        return clean
    }

    private fun guessMimeType(path: String): String {
        return when (path.substringAfterLast('.', "").lowercase()) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "application/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "ttf" -> "font/ttf"
            "woff2" -> "font/woff2"
            else -> "application/octet-stream"
        }
    }

    private fun isTextMime(mime: String): Boolean {
        return mime.startsWith("text/") ||
            mime == "application/javascript" ||
            mime == "application/json" ||
            mime == "image/svg+xml"
    }

    private fun emptyNotFoundResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            404,
            "Not Found",
            mapOf("Access-Control-Allow-Origin" to "https://$VIRTUAL_HOST"),
            ByteArrayInputStream(ByteArray(0))
        )
    }
}
